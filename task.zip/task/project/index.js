const express = require('express');
const { Client } = require('pg');
const app = express();
const PORT = 3000;

const client = new Client({
  user: 'postgres',
  host: 'localhost',
  database: 'sensor_data',
  password: ' ',
  port: 5432,
});

client.connect();

app.use(express.json());

app.post('/api/sensors', async (req, res) => {
  try {
    const { serial, swVersion, temperature, date, gps } = req.body;
    const result = await client.query('INSERT INTO sensors (serial, swVersion, temperature, date, gps) VALUES ($1, $2, $3, $4, $5) RETURNING *', [serial, swVersion, temperature, date, gps]);
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});